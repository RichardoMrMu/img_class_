Page({
  data: {
    markers: [{//东九教学楼
      iconPath: "/image/marker.png",
      id: 0,
      latitude: 30.514060, 
      longitude: 114.427050, 
      width: 15,
      height: 20
    },
      {//东校区图书馆
      iconPath: "/image/marker.png",
      id: 1,
      latitude: 30.510520,
      longitude: 114.432590,
      width: 15,
      height: 20
      },
      {//学校纪念碑
        iconPath: "/image/marker.png",
        id: 2,
        latitude: 30.513520,
        longitude: 114.409460,
        width: 15,
        height: 20
      },
      {//主校区图书馆
        iconPath: "/image/marker.png",
        id: 3,
        latitude: 30.512760, 
        longitude: 114.411910,
        width: 15,
        height: 20
      },
      {//华中科技大学青年园
        iconPath: "/image/marker.png",
        id: 4,
        latitude: 30.512580,
        longitude: 114.409120,
        width: 15,
        height: 20 
      },
      {//西区操场
        iconPath: "/image/marker.png",
        id: 5,
        latitude: 30.512587,
        longitude: 114.406503,
        width: 15,
        height: 20
      },
      {//南一楼
        iconPath: "/image/marker.png",
        id: 6,
        latitude: 30.509470,
        longitude: 114.413490,
        width: 15,
        height: 20
      },
      {//毛主席像
        iconPath: "/image/marker.png",
        id: 7,
        latitude: 30.509024, 
        longitude: 114.413406,
        width: 15,
        height: 20
      },  
      {//商鼎
        iconPath: "/image/marker.png",
        id: 8,
        latitude: 30.513960,
        longitude: 114.409270,
        width: 15,
        height: 20
      },  
      {//西十二教学楼
        iconPath: "/image/marker.png",
        id: 9,
        latitude: 30.508980, 
        longitude: 114.407470,
        width: 15,
        height: 20
      }, 
      {//紫菘开发区
        iconPath: "/image/marker.png",
        id: 10,
        latitude: 30.510679,
        longitude: 114.4030928,
        width: 15,
        height: 20
      },
    ],

    button_Text1:"上传图像",
    button_Text2:"拍摄图像"
    
  },
  takeimage:  function (){
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['camera'],
      success(res) {
        const tempFilePaths = res.tempFilePaths
        wx.showToast({
          title: 'ε=ε=ε=ε=ε=ε=┌(;￣◇￣)┘查找中,请稍后',
          icon: 'none',
          duration: 8000
        })
        wx.uploadFile({
          url: 'https://www.hhhhh.store/api/v1/uploadImage',
          filePath: tempFilePaths[0],
          name: 'file',
          formData: {
            'user': 'test'
          },
          success(res) {
            wx.hideToast()
            getApp().num = parseInt(res.data)
            wx.navigateTo({
              url: '/page/index/index'
            })
          }
        })
      }
    })
  },

  upimage: function () {
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album'],
      success(res) {
        const tempFilePaths = res.tempFilePaths
        wx.showToast({
          title: 'ε=ε=ε=ε=ε=ε=┌(;￣◇￣)┘查找中,请稍后',
          icon: 'none',
          duration: 8000
        })
        wx.uploadFile({
          url: 'https://www.hhhhh.store/api/v1/uploadImage',
          filePath: tempFilePaths[0],
          name: 'file',
          formData: {
            'user': 'test'
          },
          success(res) {
            wx.hideToast()
            getApp().num = parseInt(res.data)
            wx.navigateTo({
              url: '/page/index/index'
            })
          }
        })
      }
    })
  },
  introduction: function(event){
    wx.showToast({
      title: 'ε=ε=ε=ε=ε=ε=┌(;￣◇￣)┘加载中,请稍后',
      icon: 'none',
      duration: 8000
    })
    wx.navigateTo({
      url: '/page/index/index',
      success: function(res) {
        wx.hideToast()
        getApp().num = event.markerId;
      },

    })
  }
})